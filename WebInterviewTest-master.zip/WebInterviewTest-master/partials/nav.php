<div class="navbar navbar-default navbar-fixed-top header-nav" role="navigation">
  	<div class="container-fluid">
  	<!-- Brand and toggle get grouped for better mobile display -->
	    <div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
	        </button>
		    <a class="navbar-brand" href="/">
		      	<img src="images/LoopLogo.png" alt="Loop Logo" />
		    </a>
	    </div>
		<div class="collapse navbar-collapse site-nav" role="navigation">
		  <ul class="nav navbar-nav">
		   	<li><a href="about">About Us</a></li>
		   	<li><a href="http://www.ekoapp.com" target="_blank">Eko</a></li>
			<!-- <li><a href="jobs">Contact</a></li> -->
		  </ul>
		
		</div>
    </div>
</div>
