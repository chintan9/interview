<footer id="footer">
	<script src="http://mynameismatthieu.com/WOW/dist/wow.min.js"></script>
	<script>
	new WOW().init();
	</script>
	<div class="container wow fadeInDown animated">
		<div class="row">
			<p class="button-row">
				<a href="https://www.facebook.com/LoopByEko" target="blank"><img src="images/fb.png" alt="facebook"></a>
				<a href="https://www.twitter.com/LoopByEko" target="blank"><img src="images/twitter.png" alt="twitter"></a>
				<a href="https://www.youtube.com/channel/UCpPqOkbaD5VWw2-DHbNJBDA" target="blank"><img src="images/youtube.png" alt="youtube"></a>
				<a href="https://www.instagram.com/LoopByEko" target="blank"><img src="images/ig.png" alt="facebook"></a>
				<a href="https://plus.google.com/u/0/b/108031800239412567632/108031800239412567632/posts " target="blank"><img src="images/gplus.png" alt="twitter"></a>
				<a href="https://www.linkedin.com/company/loop-by-eko?trk=biz-brand-tree-co-name" target="blank"><img src="images/linkedin.png" alt="youtube"></a>
			</p>
		</div>
	</div>

	<br>
	<p><small>Loop By Eko</small></p>
    <p><small><a href="privacy">Privacy</a> &nbsp;|&nbsp; <a href="terms">Terms</a> &nbsp;&nbsp; <a href="tutorial"></a></small></p>
    <a href="https://mixpanel.com/f/partner"><img src="//cdn.mxpnl.com/site_media/images/partner/badge_blue.png" alt="Mobile Analytics" /></a>
	
</footer>


<!-- <footer class="container">
	<hr>
	<span>Copyright Eko Communications, Inc</span>|
	<span><a href="privacy">Privacy</a></span>|
	<span><a href="terms">Terms</a></span>
</footer> -->

<!--<span><a href="/eko.apk">Download Eko for Android</a></span>-->
